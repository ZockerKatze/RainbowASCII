import main as AA

AA.RAP("Bye Bye :3")

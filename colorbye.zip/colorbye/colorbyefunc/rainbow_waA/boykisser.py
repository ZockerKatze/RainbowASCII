import rainbow as AA

## very basic example of the usecase of RAP function
## pls someone kill me!

## call the main RAP funciton of the file rainbow (you need this file for it to wrok)
## the file can be found in my github packs!

AA.RAP(
"""
      ja-           IJa>*********>->I***********************IcMJ>*              ja>
     >Mc              {MJ*      -@OOdMM@aJ-*               jMc*                 |M-
     cM*               *ca{     *@c     *>jOMO{*         >dOI                   >M{
    >ac                  IMdI    ca>        *IcMd>      IMj*                    Idc
    {MI                    |M|   *dc*           >OMj*  >Mc*                     *OJ
    cd*                     Ida-  >aJ             *jMO>OM*                      *cd
    OJ*                       -M|  -Md>*             {M@I                       *cd
    a|                         {MMMJj|>               *jMj*                     *cd
   IM{                      *cMa-I*                      I-*                    *cd
   IM-                     c@MjJOOdMMMMMOO|                                     *cd
   IM{                     I>>>>I***   ***                                      *OJ
    a|                                                                          IOc
    OJ*                                                                         Ia|
    |a*                                                                         -M>
    >ac                                                                         OOI
     j@>                                                                       |M{
     *ad*                                        *jdM@@@@@@MMMM@@MMd>         {Mc
      *aJ*     |M@MMMMMMMMMMMMMMMM|             *a@@@@@@@@j    >aj           -Mj
       >ac       -M{    IO@@@@@@@@J             {M@@@@@@@@j     {M>        *OM{
        >aJ*    *ac*    IO@@@@@@@@J             |M@@@@@@@@j     *Od*     *|aJ*
>OOc-*   IaOI   {M-     IO@@@@@@@@c             |M@@@@@@@@j      c@I   |aM@MMMMM@M-
>M{IcaMM@@@@a   Od*     IO@@@@@@@@|             IM@@@@@@@@|      j@I           IMO*
 |M|           *MJ      *J@@@@@@@M*              J@@@@@@@d>      j@I         *cM|
  >@OI         *ad*      IM@@@@@@d                |@@@@@@I       c@I        >MJ*
    |MJ>        IMj*      Ia@@@@d    >>->*         IcdO>         >{       -da-
      -OMOI      I{*        I{{I    *{{{{>                    >{* **     OM{
       *ca**IcJJJ>*I|-*                                   * IcJc>jJ{      |M|
       |M>  **IjJcc|>*                            **        *I{Jc-         >MO*
      |M|     *II*                     >aaaOj--{OMa-          *I            *dO*
     {M|                        IMMJcaMd>**>||j|>*                           IJM>
    -M|       ***                 *III                            -Odc|>|jcJOaMMc*
    JMMMMMMMMMOd@cI*                                         **jMMd>I>|j{>I**
      *  *      *{JMac{*                              *-{{jJaaJ{*
                    *-d@MMdc>*                        *-JMjI*
                      IMJII{cddddJI                      jM>
                       *ca{                              *cM>
                         >aM|*                             OaI
                           -aMI                             JdI
                         *JM{                               *Od
                        Idd*                                 >aJ
                       *d@daMMM{                              -Mj
                            Iad                                JdI
                           *JM*                                Iaj
                           -M-                                  |M*
                           JO*                                  >a|
"""
)

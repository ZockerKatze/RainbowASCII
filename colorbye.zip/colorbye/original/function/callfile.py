## this is a basic example of a usecase for this function
import asciiarg as af ## import the file as AF

af.RAP("Marians Mutter ist eine Fette Hure") ## use the RAP function to print said text in the ()

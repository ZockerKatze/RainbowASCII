python3 bye.py
